import sys
sys.stdin = open('input.txt', 'r')

for tc in range(1, int(input())+1):
    N = int(input())
    
    base = []
    for i in range(10):
        base.append([0]*10)
    
    red = []
    blue = []
    for i in range(N):
        tmp = list(map(int, input().split()))
        if tmp[4] == 1:
            red.append(tmp)
        else:
            blue.append(tmp)

    for i in range(len(red)):
        for c in range(red[i][0], red[i][2]+1):
            for r in range(red[i][1], red[i][3]+1):
                base[c][r] = 1
    
    for i in range(len(blue)):
        for c in range(blue[i][0], blue[i][2]+1):
            for r in range(blue[i][1], blue[i][3]+1):
                if base[c][r] == 1:
                    base[c][r] = 3

    cnt = 0
    for i in range(10):
        for j in range(10):
            if base[i][j] == 3:
                cnt += 1
    
    print(f"#{tc} {cnt}")